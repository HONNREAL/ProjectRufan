drop table tournaments
create table tournaments
(
  tournamentid int primary key NOT NULL,
  displayname varchar(80),
  status bit,
  maxusers int,
  starttime varchar(10),
  endtime varchar(10),
  entryfee float
)

select * from tournaments