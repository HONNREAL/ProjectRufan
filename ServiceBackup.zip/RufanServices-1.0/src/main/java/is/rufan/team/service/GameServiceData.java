package is.rufan.team.service;

import is.rufan.team.domain.Game;

import java.util.List;

public class GameServiceData implements GameService
{
  public void addGame(Game game)
  {

  }
}
