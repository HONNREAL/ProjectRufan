package is.rufan.tournament.service;

import is.rufan.tournament.data.TournamentDataGateway;
import is.rufan.tournament.domain.Tournament;
import is.ruframework.data.RuDataAccessFactory;
import is.ruframework.domain.RuException;

import java.util.List;

/**
 * Created by Keli on 22 / 10 / 15.
 */
public class TournamentServiceData implements TournamentService {
    RuDataAccessFactory factory;
    TournamentDataGateway tournamentDataGateway;

    public TournamentServiceData() throws RuException{
        factory = RuDataAccessFactory.getInstance("tournamentdata.xml");
        tournamentDataGateway = (TournamentDataGateway) factory.getDataAccess("tournamentData");
    }

    public Tournament getTournamentById(int id) {
        return tournamentDataGateway.getTournamentById(id);
    }

    public void addTournament(Tournament tournament) {
        tournamentDataGateway.addTournament(tournament);
    }

    public void removeTournament(int id) {

    }

    public void updateTournament(int id, Tournament tournament) {

    }

    public List<Tournament> getTournaments() {

        return tournamentDataGateway.getTournaments();
    }

    public double calculateScore(int id) {
        return 0;
    }
}
