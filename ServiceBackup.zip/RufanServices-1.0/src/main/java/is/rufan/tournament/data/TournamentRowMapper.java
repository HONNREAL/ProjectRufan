package is.rufan.tournament.data;

import is.rufan.tournament.domain.Tournament;
import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Created by Keli on 22 / 10 / 15.
 */
public class TournamentRowMapper implements RowMapper<Tournament> {
    public Tournament mapRow(ResultSet rs, int rowNum) throws SQLException{
        Tournament tournament = new Tournament();
        tournament.setId(rs.getInt("tournamentid"));
        tournament.setName(rs.getString("displayname"));
        tournament.setStatus(rs.getBoolean("status"));
        tournament.setMaxEntries(rs.getInt("maxusers"));
        //tournament.setStartDate(rs.getDate("starttime"));
        //tournament.setEndDate(rs.getTimestamp("endtime"));
        tournament.setEntryFee(rs.getDouble("entryfee"));

        return tournament;
    }
}
