package is.rufan.player.data;

import is.rufan.player.domain.Player;
import is.rufan.player.service.PlayerServiceException;
import is.ruframework.data.RuData;

import java.util.List;

/**
 * Created by Keli on 22 / 10 / 15.
 */
public class PlayerData extends RuData implements PlayerDataGateway {
    public Player getPlayer(int playerId) {
        return null;
    }

    public List<Player> getPlayers(int teamId) {
        return null;
    }

    public List<Player> getPlayersByTeam(String abbreviation) {
        return null;
    }

    public int addPlayer(Player player) throws PlayerServiceException {
        return 0;
    }

    public void clearPlayers() {

    }
}
