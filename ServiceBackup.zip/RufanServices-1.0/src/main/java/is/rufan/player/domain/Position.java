package is.rufan.player.domain;

/**
 * Created by Keli on 22 / 10 / 15.
 */
public class Position {
    protected int id;
    protected String name;
    protected String abbreviation;
    protected int sequence;

    /**
     * Empty constructor for position
     */
    public Position(){

    }

    /**
     * Constructor for Position
     * @param id
     * @param name
     * @param abbreviation
     * @param sequence
     */
    public Position(int id, String name, String abbreviation, int sequence) {
        this.id = id;
        this.name = name;
        this.abbreviation = abbreviation;
        this.sequence = sequence;
    }

    /**
     * Getters and setters for Position
     * @return
     */
    public int getSequence() {
        return sequence;
    }

    public void setSequence(int sequence) {
        this.sequence = sequence;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAbbreviation() {
        return abbreviation;
    }

    public void setAbbreviation(String abbreviation) {
        this.abbreviation = abbreviation;
    }

}

