package is.rufan.player.domain;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Created by Keli on 22 / 10 / 15.
 */
public class Player {
    protected int playerId;
    protected String firstName;
    protected String lastName;
    protected int height;
    protected int weight;
    protected Date birthDate;
    protected Country nationality;
    protected int teamId;
    protected List<Position> positions = new ArrayList<Position>();

    /**
     * Empty Player Constructor
     */
    public Player(){

    }
    /**
     * Player constructor
     * @param playerId
     * @param firstName
     * @param lastName
     * @param teamId
     */
    public Player(int playerId, String firstName, String lastName, int teamId) {
        this.playerId = playerId;
        this.firstName = firstName;
        this.lastName = lastName;
        this.teamId = teamId;
    }

    /**
     * Getters and setters for Player variables
     * @return
     */
    public int getPlayerId() {return playerId;}

    public void setPlayerId(int playerId) {
        this.playerId = playerId;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public int getHeight() {
        return height;
    }

    public void setHeight(int height) {
        this.height = height;
    }

    public int getWeight() {
        return weight;
    }

    public void setWeight(int weight) {
        this.weight = weight;
    }

    public Date getBirthDate() {
        return birthDate;
    }

    public void setBirthDate(Date birthDate) {
        this.birthDate = birthDate;
    }

    public Country getNationality() {
        return nationality;
    }

    public void setNationality(Country nationality) {
        this.nationality = nationality;
    }

    public int getTeamId() {
        return teamId;
    }

    public void setTeamId(int teamId) {
        this.teamId = teamId;
    }

    public List<Position> getPositions() { return positions; }

    public void addPosition(Position position) { this.positions.add(position);  }

}
