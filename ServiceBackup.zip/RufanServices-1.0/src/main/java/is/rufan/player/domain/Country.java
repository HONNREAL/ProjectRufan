package is.rufan.player.domain;

/**
 * Created by Keli on 22 / 10 / 15.
 */
public class Country {

    protected int CountryId;
    protected String name;
    protected String abbreviation;

    public int getCountryId() {
        return CountryId;
    }

    public String getName() {
        return name;
    }

    public String getAbbreviation() {
        return abbreviation;
    }

    public void setCountryId(int id) {
        this.CountryId = id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setAbbreviation(String abbreviation) {
        this.abbreviation = abbreviation;
    }
}
