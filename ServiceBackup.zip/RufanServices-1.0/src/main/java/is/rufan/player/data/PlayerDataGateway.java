package is.rufan.player.data;

import is.rufan.player.domain.Player;
import is.rufan.player.service.PlayerServiceException;

import java.util.List;

/**
 * Created by Keli on 22 / 10 / 15.
 */
public interface PlayerDataGateway {
    Player getPlayer(int playerId);
    List<Player> getPlayers(int teamId);
    List<Player> getPlayersByTeam(String abbreviation);
    int addPlayer(Player player) throws PlayerServiceException;
    void clearPlayers();
}
