package is.rufan.player.service;

import is.rufan.player.data.PlayerDataGateway;
import is.rufan.player.domain.Player;
import is.ruframework.data.RuDataAccessFactory;

import java.util.List;

public class PlayerServiceData implements PlayerService {
    RuDataAccessFactory factory;
    PlayerDataGateway playerDataGateway;

    public PlayerServiceData(){
        factory = RuDataAccessFactory.getInstance("playerdata.xml");
        playerDataGateway = (playerDataGateway) factory.getDataAccess("playerData");
    }

    public Player getPlayer(int playerId) {
        return null;
    }

    public List<Player> getPlayers(int teamId) {
        return null;
    }

    public List<Player> getPlayersByTeam(String abbreviation) {
        return null;
    }

    public int addPlayer(Player player) throws PlayerServiceException {
        return 0;
    }

    public void clearPlayers() {

    }
}
