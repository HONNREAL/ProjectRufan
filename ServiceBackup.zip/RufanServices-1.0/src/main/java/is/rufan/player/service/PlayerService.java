package is.rufan.player.service;

import is.rufan.player.domain.Player;

import java.util.List;

/**
 * Created by Keli on 22 / 10 / 15.
 */
public interface PlayerService {
    Player getPlayer(int playerId);
    List<Player> getPlayers(int teamId);
    List<Player> getPlayersByTeam(String abbreviation);
    int addPlayer(Player player) throws PlayerServiceException;
    void clearPlayers();
}

