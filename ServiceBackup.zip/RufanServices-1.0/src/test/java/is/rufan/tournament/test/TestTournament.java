package is.rufan.tournament.test;




import is.rufan.tournament.domain.Tournament;
import is.rufan.tournament.service.TournamentService;
import junit.framework.TestCase;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.util.logging.Logger;


@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("classpath:tournamentapptest.xml")

public class TestTournament extends TestCase
{
    Logger log = Logger.getLogger(TestTournament.class.getName());

    @Autowired
    private TournamentService tournamentService;

    @Before
    public void Setup()
    {
    }

    @Test
    public void testAdd()
    {
        Tournament kelisLeague = new Tournament();

        kelisLeague.setName("KelisLeague");
        kelisLeague.setEntryFee(5000);
        kelisLeague.setMaxEntries(12);
        kelisLeague.setStatus(true);
        kelisLeague.setId(1);

        tournamentService.addTournament(kelisLeague);

        System.out.println(tournamentService.getTournamentById(1));


    }

    @Test
    public void testtournaments()
    {

    }


}
