package is.rufan.fantasypoints.data;

/**
 * Created by Keli on 25 / 10 / 15.
 */
public interface FantasyPointDataGateway {
    public void givePoints(int playerId, double points);
    public double getPoints(int playerId);

}
