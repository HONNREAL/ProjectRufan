package is.rufan.fantasypoints.process;

import is.rufan.fantasypoints.domain.FantasyPoints;
import is.ruframework.data.RuData;
import is.ruframework.data.RuDataAccess;
import is.ruframework.process.RuAbstractProcess;
import is.ruframework.reader.RuAbstractReader;
import is.ruframework.reader.RuJsonUtil;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.JSONValue;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Keli on 25 / 10 / 15.
 */
public class FantasyPointReader extends RuAbstractReader {
    public Object parse(String content){
        // Root object
        JSONArray jsonArray = (JSONArray) JSONValue.parse(content);

        List<FantasyPoints> fpList = new ArrayList<FantasyPoints>();
        int i = 0;
        for (Object o : jsonArray){
            FantasyPoints fp;
            JSONObject fpo = (JSONObject) o;
            fp = new FantasyPoints();
            fp.setPlayerid(RuJsonUtil.getInt(fpo, "PlayerId"));
            fp.setPoints(Double.parseDouble(fpo.get("FantasyPoints").toString()));
            fpList.add(fp);
            readHandler.read(i++, fp);
        }

        return fpList;
    }
}
