package is.rufan.fantasypoints.test;

import is.rufan.fantasypoints.domain.FantasyPoints;
import is.rufan.fantasypoints.service.FantasyPointService;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;

/**
 * Created by Keli on 25 / 10 / 15.
 */
public class TestFantasyPointsData {

    public static void main(String[] args) {
        /*ApplicationContext applicationContext = new FileSystemXmlApplicationContext("classpath:fantasypointapp.xml");
        FantasyPointService service = (FantasyPointService) applicationContext.getBean("fantasypointService");

        FantasyPoints fp = new FantasyPoints();
        fp.setPlayerid(23);
        fp.setPoints(1337.2f);

        service.givePoints(fp.getPlayerid(), fp.getPoints());

        System.out.println(service.getPoints(fp.getPlayerid()));*/
    }
}
