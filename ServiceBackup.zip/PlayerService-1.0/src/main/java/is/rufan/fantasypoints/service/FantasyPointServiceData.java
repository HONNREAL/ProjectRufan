package is.rufan.fantasypoints.service;

import is.rufan.fantasypoints.data.FantasyPointDataGateway;
import is.ruframework.data.RuDataAccessFactory;
import is.ruframework.domain.RuException;

/**
 * Created by Keli on 25 / 10 / 15.
 */
public class FantasyPointServiceData implements FantasyPointService {
    RuDataAccessFactory factory;
    FantasyPointDataGateway fantasyPointDataGateway;

    public FantasyPointServiceData() throws RuException
    {
        factory = RuDataAccessFactory.getInstance("fantasypointdata.xml");
        fantasyPointDataGateway = (FantasyPointDataGateway) factory.getDataAccess("fantasypointData");
    }

    public void givePoints(int playerId, double points) {
        fantasyPointDataGateway.givePoints(playerId, points);
    }

    public double getPoints(int playerId) {
        return fantasyPointDataGateway.getPoints(playerId);
    }
}
