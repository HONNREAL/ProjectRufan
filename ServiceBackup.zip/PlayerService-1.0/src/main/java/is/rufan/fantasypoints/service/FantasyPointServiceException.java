package is.rufan.fantasypoints.service;

/**
 * Created by Keli on 25 / 10 / 15.
 */
public class FantasyPointServiceException extends RuntimeException {
    public FantasyPointServiceException(){

    }

    public FantasyPointServiceException(String message){ super(message);}

    public FantasyPointServiceException(String message, Throwable cause){super(message, cause);}
}
