package is.rufan.fantasypoints.domain;

/**
 * Created by Keli on 25 / 10 / 15.
 */
public class FantasyPoints {
    protected int playerid;
    protected double points;

    public double getPoints() {
        return points;
    }

    public void setPoints(double points) {
        this.points = points;
    }

    public int getPlayerid() {

        return playerid;
    }

    public void setPlayerid(int playerid) {
        this.playerid = playerid;
    }
}
