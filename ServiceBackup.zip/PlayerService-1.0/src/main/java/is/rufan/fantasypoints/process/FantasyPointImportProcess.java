package is.rufan.fantasypoints.process;

import is.rufan.fantasypoints.domain.FantasyPoints;
import is.rufan.fantasypoints.service.FantasyPointService;
import is.rufan.fantasypoints.service.FantasyPointServiceException;
import is.ruframework.process.RuAbstractProcess;
import is.ruframework.reader.RuReadHandler;
import is.ruframework.reader.RuReader;
import is.ruframework.reader.RuReaderException;
import is.ruframework.reader.RuReaderFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.MessageSource;
import org.springframework.context.support.FileSystemXmlApplicationContext;

import java.util.logging.Logger;

/**
 * Created by Keli on 25 / 10 / 15.
 */
public class FantasyPointImportProcess extends RuAbstractProcess implements RuReadHandler {
    private FantasyPointService fantasyPointService;
    MessageSource msg;
    Logger logger = Logger.getLogger(this.getClass().getName());

    @Override
    public void beforeProcess()
    {
        ApplicationContext applicationContext = new FileSystemXmlApplicationContext("classpath:fantasypointapp.xml");
        fantasyPointService = (FantasyPointService) applicationContext.getBean("fantasypointService");
        msg = (MessageSource) applicationContext.getBean("messageSource");
        logger.info("processbefore: " + getProcessContext().getProcessName());
    }

    @Override
    public void startProcess() {
        RuReaderFactory factory = new RuReaderFactory("fantasypointprocess.xml");
        RuReader reader = factory.getReader("fantasypointReader");

        reader.setReadHandler(this);
        try
        {
            reader.read();
        }
        catch (RuReaderException e)
        {
            String errorMsg = "Unable to read specified file.";
            logger.severe(errorMsg);
        }
    }

    public void read(int count, Object o) {
        FantasyPoints fp = (FantasyPoints) o;
        try
        {
            fantasyPointService.givePoints(fp.getPlayerid(), fp.getPoints());
        }
        catch (FantasyPointServiceException se)
        {
            logger.warning("FantasyPoints with playerID " + fp.getPlayerid() + " not added " + se.getMessage());
        }
    }
}
