package is.rufan.fantasypoints.data;

import is.rufan.fantasypoints.domain.FantasyPoints;
import is.ruframework.data.RuData;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.simple.SimpleJdbcInsert;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by Keli on 25 / 10 / 15.
 */
public class FantasyPointData extends RuData implements FantasyPointDataGateway{
    public void givePoints(int playerId, double points) {
        SimpleJdbcInsert insertContent =
                new SimpleJdbcInsert(getDataSource())
                        .withTableName("fantasypoints");

        Map<String, Object> parameters = new HashMap<String, Object>(2);
        parameters.put("playerid", playerId);
        parameters.put("points", points);


        try
        {
            insertContent.execute(parameters);
        }
        catch (DataIntegrityViolationException divex)
        {
            log.warning("Duplicate entry");
        }
    }

    public double getPoints(int playerId) {
        String sql = "select * from fantasypoints where playerid = ?";

        try
        {
            JdbcTemplate queryFantasyPoints = new JdbcTemplate(getDataSource());
            FantasyPoints fp = queryFantasyPoints.queryForObject(sql, new Object[]{playerId}, new FantasyPointRowMapper());
            return fp.getPoints();
        }
        catch (EmptyResultDataAccessException e)
        {
            return 0;
        }
    }
}
