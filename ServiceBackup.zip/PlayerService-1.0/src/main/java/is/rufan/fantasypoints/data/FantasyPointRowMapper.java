package is.rufan.fantasypoints.data;

import is.rufan.fantasypoints.domain.FantasyPoints;
import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Created by Keli on 25 / 10 / 15.
 */
public class FantasyPointRowMapper implements RowMapper<FantasyPoints> {

    public FantasyPoints mapRow(ResultSet rs, int rowNum) throws SQLException
    {
       FantasyPoints fp = new FantasyPoints();
        fp.setPlayerid(rs.getInt("playerid"));
        fp.setPoints(rs.getFloat("points"));
        return fp;
    }
}
