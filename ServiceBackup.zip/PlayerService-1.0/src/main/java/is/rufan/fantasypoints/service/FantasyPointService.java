package is.rufan.fantasypoints.service;

/**
 * Created by Keli on 25 / 10 / 15.
 */
public interface FantasyPointService {
    void givePoints(int playerId, double points);
    double getPoints(int playerId);
}
