drop table playerpositions

create table playerpositions
(
  positionid int NOT NULL,
  playerid int NOT NULL
)