drop table fantasypoints

create table fantasypoints
(
  playerid int NOT NULL PRIMARY KEY,
  points float
)

select * from fantasypoints
