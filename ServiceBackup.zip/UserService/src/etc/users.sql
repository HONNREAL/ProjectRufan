
drop table users

create table users (
  id int Identity (1, 1) primary key NOT NULL,
  name varchar(128),
  username varchar(32) unique,
  email varchar(128),
  password varchar(128),
  favteamid int,
  cardnumber varchar(16),
  cardmonth varchar(2),
  cardyear varchar(2),
  securitycode varchar(3),
  cardtype varchar(80)
)

select * from users