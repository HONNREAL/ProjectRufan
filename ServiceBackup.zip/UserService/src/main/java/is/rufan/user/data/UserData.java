package is.rufan.user.data;

import is.rufan.user.domain.User;
import is.ruframework.data.RuData;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.simple.SimpleJdbcInsert;

import java.util.HashMap;
import java.util.Map;

public class UserData extends RuData implements UserDataGateway
{
  public int updateUser(User user) {
    if(user == null){
      throw new UserNotFoundException();
    }
    String sql = "select * from users where id = " + user.getId();
    JdbcTemplate queryPlayer = new JdbcTemplate(getDataSource());

    try
    {
      queryPlayer.update("update users set cardnumber = ?, cardyear = ?, cardmonth = ?, securitycode = ?, email = ?, password = ?, favteamid = ?, cardtype = ? where id = ?",
              user.getCardNumber(), user.getCardYear(), user.getCardMonth(), user.getSecurityCode(), user.getEmail(), user.getPassword(), user.getFavTeamId(), user.getCardType(), user.getId());
      return 1;
    }
    catch(EmptyResultDataAccessException erdax)
    {
      return 0;
    }
  }

  public int create(User user) throws UserDuplicateException
  {
    SimpleJdbcInsert insertUser =
        new SimpleJdbcInsert(getDataSource())
            .withTableName("users")
            .usingGeneratedKeyColumns("id");

    Map<String, Object> parameters = new HashMap<String, Object>(10);
    parameters.put("name", user.getName());
    parameters.put("username", user.getUsername());
    parameters.put("email", user.getEmail());
    parameters.put("password", user.getPassword());
    parameters.put("favteamid", user.getFavTeamId());
    /**
     * Creditcard info
     */
    parameters.put("cardnumber", user.getCardNumber());
    parameters.put("cardmonth", user.getCardMonth());
    parameters.put("cardyear", user.getCardYear());
    parameters.put("securitycode", user.getSecurityCode());
    parameters.put("cardtype", user.getCardType());

    int returnKey = 0;
    try
    {
      returnKey = insertUser.executeAndReturnKey(parameters).intValue();
    }
    catch (DataIntegrityViolationException divex)
    {
      String msg = "Username is taken";
      log.warning(msg);
      throw new UserDuplicateException(msg);
    }
    return returnKey;
  }

  public User find(int userid)
  {
    String sql = "select * from users where id = ?";
    JdbcTemplate queryPlayer = new JdbcTemplate(getDataSource());

    try
    {
      User user = queryPlayer.queryForObject(sql, new Object[]{userid},
          new UserRowMapper());
      return user;
    }
    catch(EmptyResultDataAccessException erdax)
    {
      return null;
    }
  }

  public User find(String username)
  {
    String sql = "select * from users where username = ?";
    JdbcTemplate queryPlayer = new JdbcTemplate(getDataSource());

    try
    {
      User user = queryPlayer.queryForObject(sql, new Object[]{username},
          new UserRowMapper());
      return user;
    }
    catch(EmptyResultDataAccessException erdax)
    {
      return null;
    }
  }


}
