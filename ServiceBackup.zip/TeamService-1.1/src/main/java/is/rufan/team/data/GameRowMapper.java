package is.rufan.team.data;

import is.rufan.team.domain.Game;
import is.rufan.team.service.TeamService;
import is.ruframework.data.RuDataAccessFactory;
import is.ruframework.domain.RuException;
import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Created by Keli on 22 / 10 / 15.
 */
public class GameRowMapper implements RowMapper<Game> {

    RuDataAccessFactory factory;
    TeamService teamService;

    public GameRowMapper() {
        try {
            factory = RuDataAccessFactory.getInstance("teamdata.xml");
        } catch (RuException e) {

        }
        TeamService teamService = (TeamService) factory.getDataAccess("teamData");
    }

    public Game mapRow(ResultSet rs, int rowNum) throws SQLException {
        Game game = new Game();
        game.setGameId(rs.getInt("gameid"));
        game.setStartTime(rs.getDate("starttime"));
        game.setTeamHome(teamService.getTeam(rs.getInt("hometeamid")));
        game.setTeamAway(teamService.getTeam(rs.getInt("awayteamid")));
        game.setVenue(teamService.getTeam(rs.getInt("hometeamid")).getVenue());
        return game;
    }
}
