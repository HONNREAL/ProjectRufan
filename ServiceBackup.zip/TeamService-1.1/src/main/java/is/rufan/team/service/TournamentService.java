package is.rufan.team.service;

import is.rufan.team.domain.Game;
import is.rufan.team.domain.Tournament;

import java.util.List;

/**
 * Created by Keli on 22 / 10 / 15.
 */
public interface TournamentService {
    public Tournament getTournamentById(int id);
    public void addTournament(Tournament tournament);
    public void removeTournament(int id);
    public void updateTournament(int id, Tournament tournament);
    public List<Tournament> getTournaments();
    public double calculateScore(int id);
}
