package is.rufan.team.data;

import is.rufan.team.domain.Game;

import java.util.List;

/**
 * Created by Keli on 22 / 10 / 15.
 */
public interface GameDataGateway {
    public void addGame(Game game);
    public List<Game> getGames();
}
