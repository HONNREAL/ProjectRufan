drop table tournaments
create table tournaments
(
  tournamentid int primary key NOT NULL,
  displayname varchar(80),
  status bit,
  maxusers int,
  starttime DATETIME,
  endtime DATETIME,
  entryfee float
)

select * from tournaments