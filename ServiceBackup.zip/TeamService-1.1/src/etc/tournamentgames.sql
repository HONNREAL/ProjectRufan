drop table tournamentgames
create table tournamentgames
(
  gameid int not null primary key,
  tournamentid int not null primary key
)

select * from tournamentgames