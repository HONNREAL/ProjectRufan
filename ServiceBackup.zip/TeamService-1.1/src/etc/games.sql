drop table games
create table games
(
  gameid int primary key NOT NULL,
  startTime DATETIME,
  hometeamid int not null,
  awayteamid int not null,
  venueid int,
)

select * from games