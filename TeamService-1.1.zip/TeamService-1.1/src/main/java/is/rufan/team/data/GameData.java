package is.rufan.team.data;

import is.rufan.team.domain.Game;
import is.ruframework.data.RuData;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.simple.SimpleJdbcInsert;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by Keli on 22 / 10 / 15.
 */
public class GameData extends RuData implements GameDataGateway{
    public void addGame(Game game) {
        SimpleJdbcInsert insertGame =
                new SimpleJdbcInsert(getDataSource())
                        .withTableName("games");

        Map<String, Object> gameParameters = new HashMap<String, Object>(5);
        gameParameters.put("gameid", game.getGameId());
        //gameParameters.put("location",game.getStartTime());
        gameParameters.put("hometeamid", game.getTeamHome().getTeamId());
        gameParameters.put("awayteamid", game.getTeamAway().getTeamId());
        if( game.getTeamHome().getVenue() != null)
            gameParameters.put("venueid", game.getTeamHome().getVenue().getVenueId());

        try
        {
            insertGame.execute(gameParameters);
        }
        catch (DataIntegrityViolationException divex)
        {
            log.warning("Duplicate entry");
        }
    }

    public List<Game> getGames() {
        String sql = "select * from games";
        JdbcTemplate queryPosition= new JdbcTemplate(getDataSource());

        List<Game> games = queryPosition.query(sql, (RowMapper<Game>) new GameRowMapper());

        return games;
    }
}
