package is.rufan.team.domain;

import java.util.Date;

/**
 * Created by Keli on 22 / 10 / 15.
 */

public class Tournament {
    private int id;
    private String name;
    private Date startDate;
    private Date endDate;
    private boolean status;
    private double entryFee;
    private int maxEntries;

    public Tournament(){

    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Date getStartDate() {
        return startDate;
    }

    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }

    public Date getEndDate() {
        return endDate;
    }

    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }

    public boolean isStatus() {
        return status;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }

    public boolean getStatus(){
        return this.status;
    }

    public double getEntryFee() {
        return entryFee;
    }

    public void setEntryFee(double entryFee) {
        this.entryFee = entryFee;
    }

    public int getMaxEntries() {
        return maxEntries;
    }

    public void setMaxEntries(int maxEntries) {
        this.maxEntries = maxEntries;
    }

    @Override
    public String toString() {
        return "Tournament{" +
                "id:" + id +
                ", name:'" + name + '\'' +
                ", startDate:" + startDate +
                ", endDate:" + endDate +
                ", status:" + status +
                ", entryFee:" + entryFee +
                ", maxEntries:" + maxEntries +
                '}';
    }
}

