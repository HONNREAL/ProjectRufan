package is.rufan.team.data;

import is.rufan.team.domain.Tournament;
import is.ruframework.data.RuData;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.simple.SimpleJdbcInsert;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by Keli on 22 / 10 / 15.
 */
public class TournamentData extends RuData implements TournamentDataGateway {
    public Tournament getTournamentById(int id) {
        String sql = "select * from tournaments where tournamentid = ?";
        JdbcTemplate queryTeam= new JdbcTemplate(getDataSource());

        try
        {
            Tournament tournament = queryTeam.queryForObject(sql, new Object[]{id},
                    new TournamentRowMapper());
            return tournament;
        }
        catch(EmptyResultDataAccessException erdax)
        {
            return null;
        }
    }

    public void addTournament(Tournament tournament) {
        SimpleJdbcInsert insertTournament =
                new SimpleJdbcInsert(getDataSource())
                        .withTableName("tournaments");

        Map<String, Object> tournamentParameters = new HashMap<String, Object>(7);
        tournamentParameters.put("tournamentid", tournament.getId());
        tournamentParameters.put("displayname", tournament.getName());
        tournamentParameters.put("status", tournament.getStatus());
        tournamentParameters.put("maxusers", tournament.getMaxEntries());
        tournamentParameters.put("starttime", tournament.getStartDate());
        tournamentParameters.put("endtime", tournament.getEndDate());
        tournamentParameters.put("entryfee", tournament.getEntryFee());

        try
        {
            insertTournament.execute(tournamentParameters);
        }
        catch (DataIntegrityViolationException divex)
        {
            log.warning("Duplicate entry");
        }
    }

    public void removeTournament(int id) {

    }

    public void updateTournament(int id, Tournament tournament) {

    }

    public List<Tournament> getTournaments() {
        String sql = "select * from tournaments";
        JdbcTemplate queryPosition= new JdbcTemplate(getDataSource());

        List<Tournament> tournaments = queryPosition.query(sql,
                new TournamentRowMapper());

        return tournaments;
    }

    public double calculateScore(int id) {
        return 0;
    }
}
