drop table games
create table games
(
  gameid int primary key NOT NULL,
  startTime TIMESTAMP,
  hometeamid int not null,
  awayteamid int not null,
  venueid int,
)
