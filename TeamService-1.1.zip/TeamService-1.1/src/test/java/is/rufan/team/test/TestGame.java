package is.rufan.team.test;



import is.rufan.team.domain.Game;
import is.rufan.team.domain.Team;
import is.rufan.team.service.GameService;
import is.rufan.team.service.TeamService;
import junit.framework.TestCase;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.util.Date;
import java.util.List;
import java.util.logging.Logger;


@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("classpath:gameapptest.xml")

public class TestGame extends TestCase
{
    Logger log = Logger.getLogger(TestTeam.class.getName());

    @Autowired
    private GameService gameService;

    @Autowired
    private TeamService teamService;

    @Before
    public void Setup()
    {
    }

    @Test
    public void testAbbreviation()
    {
        Game game = new Game();
        game.setGameId(1);
        game.setTeamAway(teamService.getTeams().get(1));
        game.setTeamHome(teamService.getTeams().get(2));
        game.setVenue(teamService.getTeams().get(2).getVenue());

        gameService.addGame(game);


    }

    @Test
    public void testTeams()
    {

    }


}
